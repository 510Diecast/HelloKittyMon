# Roster status

14 original animated fan sprites; 34 art-pending registry entries.

## Finished animated art

- Hello Kitty
- My Melody
- Kuromi
- Cinnamoroll
- Pompompurin
- Pochacco
- Keroppi
- Badtz-Maru
- Chococat
- Tuxedosam
- Gudetama
- Hangyodon
- Kiki
- Lala

All finished sheets: 32x32 canvas; four frames in seven states (28 frames / character).

## Art pending — unavailable in gallery

- My Sweet Piano
- Charmmy Kitty
- Dear Daniel
- Pekkle
- Usahana
- Marroncream
- Cogimyun
- Marumofubiyori
- Corocorokuririn
- Hanamaruobake
- Kirimichan
- Sugarbunnies
- Shirousa
- Kurousa
- Aggretsuko
- Bonbonribbon
- Wish me mell
- Monkichi
- Minna no Tabo
- Spottie Dottie
- Lloromannic
- Mocha
- Mewkledreamy
- Nyantaro
- Goropikadon
- Patty and Jimmy
- Pandapple
- Cheery Chums
- Jewelpet
- Beatcats
- Adorozatorumary
- Ichigoman
- Gaopowerroo
- Lovelymocha

Directory coverage checked against the Sanrio storefront character menu on 2026-11-14:
https://www.sanrio.com/collections/characters/na-013125

Kiki and Lala are separate entries for Little Twin Stars. Usahana represents U*SA*HA*NA.
Extra requested/documented characters are included as pending entries. The registry is a snapshot,
not a claim to enumerate every Sanrio character ever created or future directory changes.
