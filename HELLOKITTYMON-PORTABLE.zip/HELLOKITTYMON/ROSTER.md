# Roster status — artwork v2

11 reviewed replacement sets; 37 unavailable art-pending entries.

## Reviewed replacements

- Hello Kitty
- My Melody
- Kuromi
- Cinnamoroll
- Pompompurin
- Pochacco
- Keroppi
- Badtz-Maru
- Chococat
- Kiki
- Lala

Each set: 4 original idle keys + 4 original walk keys; 32px canvas, baseline row 29.
Runtime sheets: 28 cells / character with deliberate reuse across seven behavior states.

## Withdrawn previous artwork

- Tuxedosam — old template rejected; replacement pending.
- Gudetama — old template rejected; replacement pending.
- Hangyodon — old template rejected; replacement pending.

## All pending entries — cannot be added

- Tuxedosam
- Gudetama
- Hangyodon
- My Sweet Piano
- Charmmy Kitty
- Dear Daniel
- Pekkle
- Usahana
- Marroncream
- Cogimyun
- Marumofubiyori
- Corocorokuririn
- Hanamaruobake
- Kirimichan
- Sugarbunnies
- Shirousa
- Kurousa
- Aggretsuko
- Bonbonribbon
- Wish me mell
- Monkichi
- Minna no Tabo
- Spottie Dottie
- Lloromannic
- Mocha
- Mewkledreamy
- Nyantaro
- Goropikadon
- Patty and Jimmy
- Pandapple
- Cheery Chums
- Jewelpet
- Beatcats
- Adorozatorumary
- Ichigoman
- Gaopowerroo
- Lovelymocha

No blank or substitute character is presented as complete. Gallery source references and
per-character review notes are recorded in artwork/manifest.json inside SOURCE.zip.

Directory snapshot reference: https://www.sanrio.com/collections/characters/na-013125
Kiki and Lala are separate Little Twin Stars entries. This is not every Sanrio character ever created.
