﻿# HELLOKITTYMON — artwork upgrade v2

Tiny offline Windows desktop pets for personal, noncommercial fan use. Not affiliated with
Sanrio or Deskmon. This release replaces the shared-template artwork with eleven reviewed,
character-specific AI-assisted fan sprite sets; the original off-model art is not selectable.

## Launch and configure

Double-click `HELLOKITTYMON.exe`. No Python, installer, administrator access, account or internet
is required. Windows 10/11 with its standard .NET Framework 4.x runtime is required.
Three pets begin roaming above the taskbar with a 32px sprite canvas at 125% scale (40 physical px).
The normal control window stays hidden. Double-click the notification-area pet icon, including
in the overflow menu, to search, add duplicates, remove pets or change preferences.

Left-drag a pet to pick it up; release to settle at the nearest monitor's bottom work-area edge.
Right-click for pet animation, sit/roam, next monitor, remove, or the pet room.
The tray provides show/hide all, quiet mode, restart and exit. Close the pet room to keep roaming.

Preferences include scale (50–300%), speed (0–60 px/sec), maximum (1–40), opacity (30–100%),
quiet/reduced-animation mode, pet interaction on/off, optional mouse following, fullscreen
pause/hide, and user login launch. Login launch and mouse following are off by default.
Disabling pet interaction also makes the artwork click-through; re-enable it through the tray.
The active-list Sit / roam species control affects all pets of that character type.
Reset preferences restores default controls and caps the current roster at 12; it preserves
active pets up to that cap. A separately enabled user login shortcut must be disabled via its checkbox.
No global keyboard hooks, security changes, network services or paid APIs are used at runtime.

Settings and a bounded log normally live in `%LOCALAPPDATA%\HELLOKITTYMON`. If access is denied,
the app uses a `user-data` folder beside the EXE. Keep that folder to preserve preferences.
Only one ordinary instance runs per Windows session. Moving the EXE requires updating any login
shortcut by toggling that option off and on. Device execution policy can restrict unsigned builds.

## Review the artwork

Run `OPEN-GALLERY.cmd` to open `ART-COMPARISON.html` specifically in Google Chrome. The gallery
works offline: all images and animation data are embedded. It provides rejected-before versus
after comparisons, character-specific walking cadences, idle/blink playback, pause, light/dark/checker
backgrounds, 32/40/48 physical-pixel size options, and enlarged walking-keyframe inspection.
It compensates for browser display ratio. Native desktop sprites remain nearest-neighbor rendered.
At noninteger scales, some source pixels occupy different output widths; 100/200/300% scales
produce perfectly uniform pixel blocks. The 40px default retains sharp edges and matches the
requested tiny desktop-pet range, not an independently measured local Deskmon screenshot.

Ready: Hello Kitty, Kuromi, My Melody, Cinnamoroll, Pompompurin, Pochacco, Keroppi, Badtz-Maru,
Chococat, Kiki and Lala. See `ROSTER.md` for 37 pending entries. The previous Tuxedosam, Gudetama
and Hangyodon art was rejected and withdrawn rather than retained as a claimed finished asset.

Every finished set has four original idle key poses and four original walking key poses, normalized
to a 32px canvas with hard transparency, a stable <=20-color palette and baseline row 29.
The 7-state runtime sheets contain 28 frame cells per character, with intentional pose reuse:
blink/rest/sleep/jump/special reuse approved poses instead of squashing or warping bodies.
They are not 28 independently illustrated poses. Walking has actual limb changes and individual
contact/pass timing; idle holds are long with a short blink. Random repeated blink bursts are removed.

Original artwork was made with the built-in imagegen tool using character-specific prompts and
canonical official profile references, then technically imported to the final pixel grid. No official
bitmap, game sprite, unauthorized pack, or Deskmon asset is included. No third-party sprite license
is claimed. Source sheets, exact prompts, provenance, references and review notes are in `SOURCE.zip`.
Review is internal quality assessment, not approval by Sanrio or a guarantee of identical official art.

## Preserve and extend

The roaming implementation, tray, dragging, masking, settings, taskbar avoidance, fullscreen
pause and monitor reassignment remain in place. Animation timing now supports per-frame durations
and resets when a pet changes states. Older external packs without timing metadata still work.
Arbitrary application window-edge sitting is not implemented.

See `PACK-FORMAT.md` for authorized personal packs. Bad optional overrides are logged and skipped,
leaving embedded art usable. Pending roster entries cannot be added. Core embedded art is pinned
by review checksums; changed source images or sheets require renewed visual review before building.

Extract `SOURCE.zip`, run `python tools/validate_assets.py`, then
`powershell -NoProfile -File tools/build.ps1`. The Windows compiler is used without NuGet/network.
Development requires Python with Pillow for asset tools; Node is used for gallery logic tests.
`python tools/generate_assets.py` reimports the approved source sheets rather than recreating
old templates. Use `python tools/build_gallery.py` to rebuild the gallery. External packs do not
need this development pipeline. See `ART-REVIEW.md` and `QA.md` for checks and remaining limits.

The release remains in a user Temp folder because permanent project/Downloads writes were denied.
Move the complete HELLOKITTYMON-RELEASE folder to a permanent writable location before regular use.
