﻿# HELLOKITTYMON

A tiny offline Windows desktop pet application for personal, noncommercial fan use.
Original code and simple original pixel fan art. Not affiliated with Sanrio or Deskmon.

## Start

Double-click `HELLOKITTYMON.exe`. Three 40-physical-pixel friends start roaming above the taskbar.
The app normally has no control window. Find the small pet icon in the notification area (possibly
under the Windows overflow arrow), then double-click it or right-click > Open little pet room.
Right-click any pet to open its menu. Exit from the tray or the pet room.

Windows 10/11 desktop with the standard .NET Framework 4.x runtime is required. The build uses
the installed Windows framework; no Python, administrator account, downloads, cloud service,
API key, or internet connection is needed at runtime. No installer or registry edits.
This is an unsigned personal build; device policy may restrict it. Respect that policy.

## Controls

- Friends: search the 48-entry registry, select finished art, Add selected friend. Duplicates work.
- Select an active friend and Remove; Sit / roam species toggles movement for that character type.
- Drag a sprite with the left mouse button. It settles at the bottom of the nearest monitor on release.
- Right-click: pet animation, sit/roam this individual, next monitor, remove, or open the pet room.
- Preferences: scale 50–300%, speed 0–60 physical pixels/sec, maximum 1–40, opacity 30–100%.
- Quiet mode reduces animation and movement. Mouse following is optional and off by default.
- Disable dragging to make pets themselves click-through; use the tray to turn it back on.
- Show/hide all is available in Preferences and the tray. Fullscreen auto-pause/hide is on by default.
- Login startup is off by default. Enabling it creates only a user Startup-folder command file.
  Disable it before moving the EXE; re-enable afterward to update the path.
- Close the pet room to keep roaming. Tray Restart reloads the app. Exit stops all timers and pets.
- Reset preferences restores defaults, keeping the currently active roster. It does not disable a
  separately enabled login shortcut; use its checkbox to disable that shortcut.

Sprites use physical pixels deliberately, including on mixed-DPI displays. At 100% sprite scale,
the canvas is 32px; the default 125% is 40px. Artwork uses nearest-neighbor resampling without
smoothing. Integer scales (100/200/300%) give perfectly uniform pixel blocks; intermediate
scales retain sharp edges with some differently sized pixel blocks.

The app uses the monitor working area to avoid taskbars on any edge. Existing pets are assigned
to monitors and can be dragged across them or moved with their menu. Display-layout changes
reclamp positions. Optional sitting on arbitrary application window edges is not implemented.

## Settings and logs

Settings and a size-limited log normally live in `%LOCALAPPDATA%\HELLOKITTYMON`.
If that location is denied, the application uses `user-data` beside the EXE; keep that folder to
preserve preferences. If neither location is writable, startup fails with a clear error.
Only one ordinary instance is allowed per Windows session. No global keyboard hooks.

## Artwork and packs

14 finished animated characters; 34 clearly marked art-pending registry slots. Pending entries
cannot be added and never silently become another character. See `ROSTER.md` for exact status.
Each finished character has idle/blink, a two-step walk, compressed sitting, sleepy blinking /
breathing, a small jump, and a special gesture. These are deliberately simple pixel fan sprites,
not official Sanrio art, game rips, or Deskmon assets. Some specials share a happy gesture.

Editable PNG sheets and JSON metadata are in `SOURCE.zip`. See `PACK-FORMAT.md` to add art
without changing code. A missing or invalid optional pack is logged and skipped; embedded default
art remains usable. Embedded assets mean the EXE can be copied on its own.

## Building from source

Extract `SOURCE.zip`. Run `powershell -NoProfile -File tools/build.ps1` from that folder.
The installed Windows .NET Framework compiler builds the EXE without NuGet or network access.
The validation command requires Python with Pillow **only for development**. Regenerate the
sheets with `python tools/generate_assets.py`, or edit PNGs in your pixel editor and use
`python tools/pack_assets.py` before rebuilding. Source is C# compatible with the Windows compiler.
Do not run `refine_*` scripts repeatedly; those were development transformation scripts and are
excluded from the source archive.

## Verification

See `QA.md` and `evidence/` for executed tests and limits. In this build environment desktop
screen capture and the real underlying application hit target were unavailable. Native application
renders, asset validation, real HWND style/region tests, model-level drag tests, persistence,
single-instance behavior, missing optional art handling, executable startup and graceful exit were
exercised. These do not replace a manual click/drag test on your ordinary desktop.
