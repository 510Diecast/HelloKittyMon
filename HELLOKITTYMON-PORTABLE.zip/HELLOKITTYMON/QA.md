﻿# QA report — HELLOKITTYMON

Build date: 2026-11-14. Platform: Windows, installed .NET Framework compiler.

## Executed successfully

- All 14 original RGBA sheets, 392 frames, metadata, required states, dimensions,
  transparency and distinct idle/walk/sleep/special frame content validated.
- Packaged executable loaded its embedded assets and created native pet windows.
- Independent movement, bounds clamping, all animation state frame indexes, global scale,
  speed zero, quiet mode, adding duplicates, removing, active cap and show/hide checks.
- Settings serialized to disk and were deserialized with matching roster and scale.
- Pet HWND has WS_EX_NOACTIVATE; roaming did not change the current foreground value.
- Transparent pixels are excluded by the real native window region. WindowFromPoint
  at an opaque sprite pixel returned the pet HWND; at an empty pixel it did not.
- Setting full pet click-through set WS_EX_TRANSPARENT. Mask construction and restoration
  were exercised by the app while animating.
- Model-level drag moved the native window and release returned it inside the work area.
- Gallery search selected the expected two Kitty results. Application-drawn gallery,
  preferences and native-size pet renders were visually reviewed.
- A broken optional Hello Kitty override with a missing PNG was skipped; embedded art
  remained available and all three default pets started.
- Normal packaged startup and graceful timed shutdown returned exit code 0.
- A concurrent second instance exited instead of duplicating pets.
- A replacement process waited for the singleton mutex, started after the original
  exited, and then shut down with exit code 0.
- A two-minute real Windows Forms message-loop stability run completed with clean shutdown.
  An earlier run measured approximately 72 MB working set with five active pets.

Machine-readable results and logs are in `evidence/`. `passed: true` means the executed
component assertions passed; it does not mean blocked manual tests were performed.
The self-test runs the actual packaged executable, using separate QA settings and mutex.

## Restricted-session limitations — NOT verified

The screenshot API returned `The handle is invalid`; Pillow desktop capture also failed.
An empty-pixel WindowFromPoint returned zero instead of the underlying test-form HWND.
The test confirms exclusion of the pet, but cannot confirm real user clicks reaching an
ordinary application. The mouse delivery check posts messages directly to a test HWND;
it is not evidence of a physical mouse click passing through the overlay.

Similarly, drag tests invoke the drag model and native window movement, rather than
injecting a physical drag. Foreground focus checks in this restricted desktop are limited.
Only one monitor was exposed. Mixed DPI, real taskbar positions, display hotplug,
fullscreen games and exclusive fullscreen, login startup, actual tray interaction, and
manual mouse dragging require an ordinary unlocked desktop for final acceptance.
These features have usable implementations, but those hardware/desktop scenarios were
not exercised here. Arbitrary application-window edge sitting is not implemented.

No local Deskmon installation was found by the targeted Downloads name search. Its
public page was read for the bottom-edge roaming concept; no software was modified.
Since a usable local visual reference was unavailable, the requested 32–48 physical
pixel default was used: sprites have a 32px canvas and default to 40px. The contact sheet
is enlarged 3x for art inspection. `native-pet-render.png` is an application render at its
real 40px canvas size, not a screenshot of your desktop.

## Recovery and release location

The declared user-root workspace and Downloads rejected directory creation. No permissions
or security settings were changed. The build and release were created in the writable user
Temp directory. Move the entire HELLOKITTYMON-RELEASE folder to a permanent location before
regular use. Normal preferences use LocalAppData, with a sibling user-data fallback if denied.

## Manual acceptance on an ordinary desktop

1. Start the EXE. Confirm three tiny pets above the taskbar; open controls from the tray.
2. Click and type in an ordinary underlying app, including transparent holes next to a pet.
   Confirm the underlying app retains keyboard focus while pets roam.
3. Drag a pet, release it, change scale, add duplicates, remove one and toggle quiet mode.
4. Disable pet interaction; confirm a click on the art also reaches the underlying app.
   Re-enable interaction from the tray.
5. Open a fullscreen app; confirm pets hide and pause, then resume after leaving fullscreen.
6. Test each connected monitor, scale setting, taskbar edge and monitor disconnection.
7. Change preferences and roster, Exit, restart, and confirm they persist.
8. If desired, enable login startup, test it on a later sign-in, then disable it again.

## Reproduce automated checks

Development: `python tools/validate_assets.py`, then `powershell -NoProfile -File tools/build.ps1`.
Runtime: `HELLOKITTYMON.exe --self-test C:\writable-folder\qa-results.json`.
The report directory must exist. The self-test takes around two minutes and quits the app.
`HELLOKITTYMON.exe --smoke-test` exercises normal data paths, startup and timed shutdown.
