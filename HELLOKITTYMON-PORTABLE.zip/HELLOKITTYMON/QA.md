﻿# QA — artwork upgrade v2

Date: 2026-11-14. Native Windows Forms build using the installed .NET Framework compiler.
No global installs, new paid service, admin access or security changes were used.

## Executed checks

- 11 reviewed sets / 308 runtime frame cells validated: approved source/sheet hashes,
  dimensions, binary alpha, <=20 colors, transparent margins, baseline row 29, idle variation,
  real lower-body walk changes, nontranslation key poses and per-frame timing metadata.
- Negative art gate: a valid control passed; 9 malformed/unreviewed fixtures were rejected.
  Cases: changed/unapproved art, wrong dimensions, opaque background, blank frame,
  shifted baseline, static walk, palette overflow, invalid timing and clipped edges.
- 29 runtime assertions passed in the packaged EXE, including all original roaming checks,
  per-frame idle/walk timing, state phase reset, selection/search, duplicate add, remove, cap,
  show/hide, quiet mode, zero speed, scale, bounds, settings serialization, HWND region/style,
  model-level dragging, missing/invalid asset rejection and two-minute stability.
- Final native UI harness passed: rendered gallery and preference controls, actual-size pet
  output, reset of 15 pets to default cap 12, invalid timing rejection and legacy fps fallback.
- 11 gallery logic checks passed in Node using DOM/canvas stubs: data load, physical sizing
  at display ratios 1/1.25/2, 48px control, walk and blink timing, clock, play/pause/resume,
  animation switch/reset and background selection. JavaScript syntax check passed.
- Normal final EXE startup and clean shutdown returned 0. A second instance exited instead of
  duplicating pets. A replacement waited for the mutex, started and exited 0 after restart.
- A missing optional Hello Kitty sheet was skipped, and embedded default art remained usable.
- Portable/source ZIP CRCs and packaged binary hashes are checked by the packaging tool.
  The extracted portable EXE is separately started and shut down; evidence is included.

Final runtime stability working set: approximately 72 MB with four active pets. No crash or
application exception was logged in the final runtime run. Per-character animation timings
are stored in metadata; the idle blink lasts 120ms after a long open-eye hold.

## Visual review

All eleven 4x2 raw sources and their normalized 32px idle/walk frames were reviewed. Enlarged
and native-size contact sheets plus real application control renders are included. Walking
uses different body/limb poses, not a shifted single sprite. Raw generated art is normalized to
hard pixel edges; native enlargement uses nearest-neighbor only. No official bitmap is bundled.

The gallery compares against the rejected old custom art, not copied Deskmon art. The requested
32–48 physical pixel range is available; default canvas size is 40px. A usable local Deskmon
reference was not found, so exact screenshot-calibrated equivalence is not claimed.

## Restricted-session limits — NOT verified

Chrome automation failed before a usable screenshot could be captured. The Playwright driver
was denied with WinError 5; native Chrome exited without creating a reference capture. Edge was
not used. Therefore the gallery has logic/syntax checks and direct PNG review, but no claimed
full browser layout/screenshot test. Run OPEN-GALLERY.cmd in ordinary Chrome to inspect it.

Windows screen capture returns `The handle is invalid`. Empty sprite pixels are excluded from
the native pet HWND, but WindowFromPoint returns zero rather than the underlying test window in
this restricted desktop. The posted mouse-message check is not a physical click-through test.
Dragging assertions invoke the drag model and native window movement, not a physical mouse drag.
Foreground-value comparisons in this session also have limited meaning.

Only one monitor is exposed. Physical mouse click-through, real dragging/focus, mixed-DPI monitor
hotplug, taskbar-edge configurations, fullscreen games and login startup require an ordinary
unlocked desktop for final manual acceptance. The corresponding existing implementations were
preserved; passing component checks do not certify those unexercised hardware scenarios.

## Manual desktop acceptance

1. Start the EXE; verify the three tiny pets are above the taskbar and the tray opens preferences.
2. Open an ordinary application; click and type around transparent pet holes and confirm focus.
3. Drag/release a pet; disable pet interaction and test clicking through the artwork itself.
4. Add duplicates, remove one, adjust scale and speed, toggle quiet mode and show/hide all.
5. Test fullscreen hide/pause and all actual monitors/taskbar locations; unplug a monitor.
6. Exit/restart and confirm settings persist. Login startup is optional and off by default.
7. Use the offline art gallery at 32, 40 and 48 physical px to review the character identities.

## Reproduce

Development requires Python with Pillow, and Node for gallery logic tests:

```
python tools/validate_assets.py
python tools/test_asset_gate.py
python tools/build_gallery.py
node tools/test_gallery.js
powershell -NoProfile -File tools/build.ps1
powershell -NoProfile -File tools/verify.ps1
```

Runtime: `HELLOKITTYMON.exe --self-test C:\existing-writable-folder\qa-results.json` runs a
separate two-minute scenario and exits. `--smoke-test` uses normal data paths and exits shortly.
Test results are in evidence/. The application itself does not require Python or Node.

The working release is in Temp because permanent user-root/Downloads writes were denied.
Move the release folder to a permanent writable location before regular use.
