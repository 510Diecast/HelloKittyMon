﻿# Artwork review — v2

The previous generator reused a round head, oval body, fixed eye positions and nearly identical
nose/mouth placement. Accessories were layered onto that shared template. Walking mostly shifted
or resized the full sprite. This erased character-specific anatomy, introduced noses or mouths
where they did not belong, reduced distinctive eyes to dots and produced generic gestures.
All 14 previous template designs were rejected for this release. They remain only in the local
v1 recovery archive and in explicitly labeled before-comparison thumbnails.

## Replacement process

1. Official Sanrio profile pages supplied reference identities; character-specific prompts record
   silhouette, face spacing, palette, clothes, ears, tail and accessories. No official artwork is bundled.
2. Eleven separate original 4x2 source sheets were produced with built-in imagegen, rather than
   using a cat/dog template or a third-party sprite pack. Exact prompts: artwork/prompts.json.
3. Each source sheet was inspected, then its four idle and four walking keys were reviewed on
   the 32px target grid and enlarged. This is AI-assisted original fan art, not hand-pixelled licensed art.
4. Technical import preserves aspect ratio and uses nearest-sampled color with area-derived hard
   alpha coverage to prevent thin-line gaps. Final pixels have alpha 0 or 255 and <=20 colors/set.
   No runtime smoothing, drop shadow, colored transparency fringe, image warp or resizing-based gait.
5. Source poses are normalized to baseline row 29 with transparent margins. Wide Cinnamoroll has
   a deliberately shorter body; tall rabbits and children keep their own silhouette proportions.
6. Approved source and final-sheet SHA256 values are pinned in artwork/manifest.json. Changing either
   requires renewed visual approval; a build cannot silently accept a changed off-model sheet.
7. Frame timing distinguishes idle holds, quick blinks, walking contact and passing poses. Every
   character has a separate walking cadence. State changes start at frame zero.

## Identity checks applied

- Hello Kitty: wide mouthless white face, yellow nose, whiskers, red bow, red shirt and blue overalls.
- Kuromi: jester hood with pointed ears, pink skull, white face/body, impish eyes and devil tail.
- My Melody: pink hood, one bent ear, small flower, white face/body and yellow nose.
- Cinnamoroll: long broad floppy ears, blue eyes and mouth, pink cheeks, curled tail; no invented nose.
- Pompompurin: pudding-shaped custard body, floppy ears, brown beret, tiny brown muzzle.
- Pochacco: white puppy with black ears, forehead tuft, black nose, red shirt and athletic gait.
- Keroppi: protruding white eyes, green face, cheek circles, V smile, striped shirt; no nose.
- Badtz-Maru: spiky black penguin, white half-lidded eyes, yellow beak/feet, white belly and waddle.
- Chococat: white sclera/black pupils, brown nose, pink inner ears, blue collar, tail and whiskers.
- Kiki: short blue hair, white tunic, bare feet and yellow back star.
- Lala: distinctly long pink hair, white tunic, bare feet and small star wand.

All eleven passed internal visual review of the raw sources and normalized idle/walk keys. The
review manifest contains per-character notes. This assessment does not represent Sanrio approval
or an independent professional artist's sign-off. Remaining artwork may be refined further.

## Rejected and withheld

The old Tuxedosam, Gudetama and Hangyodon designs have no acceptable replacement in this pass.
They are unavailable rather than silently reused. All other 34 pre-existing pending slots remain
pending. The source archive and runtime resource ZIP include approved assets only. Before thumbnails
are clearly labeled rejected. No unauthorized or ripped art is shipped.

## Automated rejection gate

The asset gate checks reviewed checksums, metadata, dimensions, transparency, palette budget,
clear margins, baseline, idle changes, nonidentical lower-body walk keys, nontranslation motion
and valid frame timings. A valid fixture passed. Nine negative fixtures were rejected: unreviewed
change, wrong dimensions, opaque background, blank frame, shifted baseline, static walk,
palette overflow, invalid timing and clipped edges. Technical tests do not prove character identity;
visual review is a separate required step.

## Scale and reference limits

The offline comparison gallery uses 32/40/48 physical-pixel canvases, defaulting to the app's
40px physical canvas. The gallery adjusts CSS size using devicePixelRatio. The enlarged view is
for inspecting pixel clusters and gait. No local Deskmon reference was found in the targeted
Downloads/Desktop/Personal-Projects search. The requested size range is used instead of claiming
an exact measured Deskmon match. Chrome automation and desktop capture are unavailable in this
restricted session; PNG contact sheets were inspected directly and gallery logic was tested in Node.

Official references (also linked per character in the gallery):
https://www.sanrio.co.jp/characters/hellokitty/
https://www.sanrio.co.jp/characters/kuromi/
https://www.sanrio.co.jp/characters/mymelody/
https://www.sanrio.co.jp/characters/cinnamon/
https://www.sanrio.co.jp/characters/pompompurin/
https://www.sanrio.co.jp/characters/pochacco/
https://www.sanrio.co.jp/characters/keroppi/
https://www.sanrio.co.jp/characters/badtzmaru/
https://www.sanrio.co.jp/characters/chococat/
https://www.sanrio.co.jp/characters/kikilala/
Deskmon concept/size-range reference: https://creaturesaint.itch.io/deskmon
