﻿# Character pack format — v2, backwards compatible

Put authorized/original character packs under `packs/<id>/` beside the EXE or under
`%LOCALAPPDATA%/HELLOKITTYMON/packs/`. Each contains `character.json` and `sprites.png`.
Restart to load. Invalid optional overrides are skipped; the embedded default remains usable.
No executable pack scripts run. Do not use ripped or unauthorized game art.

```json
{
 "id": "my-friend", "name": "My Friend", "status": "animated",
 "sheet": "sprites.png", "width": 32, "height": 32,
 "frames": 4, "fps": 6,
 "states": ["idle", "walk", "blink", "sit", "sleep", "jump", "special"],
 "frameDurationsMs": {
  "idle": [2500,450,120,900], "walk": [170,110,170,110]
 }
}
```

Rows are states in metadata order; frames run left to right. This example is 128x224 pixels.
Each frame needs transparent and visible pixels. Dimensions may be 8–128, frames 2–16,
and fallback fps 1–15. All seven states are required. Use alpha 0/255 for crisp pixel art.
Each optional timing array must contain exactly `frames` positive integer durations from 20–10000ms.
States without a timing array use `fps`. Legacy packs without frameDurationsMs continue to work.
Source sprites face forward/right; left-facing movement mirrors them. State transitions reset timing.

Built-in v2 art uses 32px cells, a 29px baseline, clear margins and <=20 colors per character.
Use real leg/arm/appendage changes, a stable head and a brief blink. Do not translate or squash
one generic sprite and call it a walking cycle. The runtime handles positioning, facing and jumping.

To change embedded art, update original files under artwork/raw and the review manifest. Inspect
idle/walk keys at actual size and enlarged, record provenance/permission and review notes, then
pin the approved source and sheet hashes. `python tools/import_artwork.py` technically normalizes
the source grid; `python tools/validate_assets.py` rejects unreviewed changes and malformed output.
`python tools/pack_assets.py` includes only accepted registry entries, then build with tools/build.ps1.
The quality gate is for this project's reviewed art; arbitrary external packs remain the user's responsibility.
