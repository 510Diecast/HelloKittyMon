﻿# Character pack format, version 1

Create `packs/<your-character>/` beside the EXE, or under `%LOCALAPPDATA%/HELLOKITTYMON/packs/`.
Each pack contains `character.json` and a transparent RGBA PNG sheet. Restart to reload packs.
Packs with the same ID override embedded art only after successful validation. Invalid overrides
leave the built-in character intact. New IDs extend the gallery. No executable pack scripts run.

Example `character.json`:

```json
{
 "id": "my-original-friend",
 "name": "My Original Friend",
 "status": "animated",
 "sheet": "sprites.png",
 "width": 32,
 "height": 32,
 "frames": 4,
 "states": ["idle", "walk", "blink", "sit", "sleep", "jump", "special"],
 "fps": 5,
 "artist": "Your name / permission and origin"
}
```

Frames run left to right; animation states run top to bottom in metadata order.
For this example the sheet is 128x224 pixels. Each frame must have transparent and visible pixels.
Use alpha 0 for empty space and 255 for solid pixel art. The engine masks alpha above 100.
Keep a small transparent margin on every side and feet near the last rows. Face forward or right;
leftward motion mirrors the sprite. Canvas dimensions can be 8–128; frames 2–16; fps 1–15.
All seven named states are required. The runtime applies walking, jumping and facing movement.
Base animation state timing is intentionally gentle, randomized and independent per pet.

The registry in `assets/registry.json` lists selectable and art-pending slots. For an embedded
addition add metadata and the sheet under `assets/<id>/`, then regenerate `assets.zip` with
`python tools/pack_assets.py` and build. The generator is an editable drawing source for the
original artwork; running it overwrites generated sheets. Back up manual edits before regeneration.
All art must be original or supplied with authorization. Do not import ripped game sprites.
