@echo off
set "HELLOKITTYMON_CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist "%HELLOKITTYMON_CHROME%" (
 echo Google Chrome was not found at the expected location. This launcher does not use another browser.
 pause
 exit /b 1
)
start "" "%HELLOKITTYMON_CHROME%" "%~dp0ART-COMPARISON.html"
