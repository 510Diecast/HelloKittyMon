Optional original/authorized character packs go in subfolders here. See PACK-FORMAT.md. No external packs are required.
