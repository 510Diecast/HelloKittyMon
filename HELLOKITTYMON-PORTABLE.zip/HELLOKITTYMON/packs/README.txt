Optional original/authorized character packs go in subfolders. See PACK-FORMAT.md. Embedded assets need no packs.
